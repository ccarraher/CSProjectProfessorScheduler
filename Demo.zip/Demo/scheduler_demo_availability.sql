-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: scheduler_demo
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `availability`
--

DROP TABLE IF EXISTS `availability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `availability` (
  `NetID` varchar(255) NOT NULL,
  `Day` varchar(255) NOT NULL,
  `TimeSlot` varchar(255) NOT NULL,
  PRIMARY KEY (`NetID`,`Day`,`TimeSlot`),
  CONSTRAINT `availability_ibfk_1` FOREIGN KEY (`NetID`) REFERENCES `user` (`NetID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `availability`
--

LOCK TABLES `availability` WRITE;
/*!40000 ALTER TABLE `availability` DISABLE KEYS */;
INSERT INTO `availability` VALUES ('axc157030','Monday','1:00pm - 1:30pm'),('axc157030','Monday','1:30pm - 2:00pm'),('axc157030','Monday','2:00pm - 2:30pm'),('axc157030','Monday','8:30am - 9:00am'),('axc157030','Monday','9:00am - 9:30am'),('axc157030','Monday','9:30am - 10:00am'),('axc157030','Thursday','10:00am - 10:30am'),('axc157030','Thursday','10:30am - 11:00am'),('axc157030','Thursday','11:00am - 11:30am'),('axc157030','Tuesday','10:00am - 10:30am'),('axc157030','Tuesday','10:30am - 11:00am'),('axc157030','Tuesday','11:00am - 11:30am'),('axc157030','Wednesday','1:00pm - 1:30pm'),('axc157030','Wednesday','1:30pm - 2:00pm'),('axc157030','Wednesday','2:00pm - 2:30pm'),('axc157030','Wednesday','8:30am - 9:00am'),('axc157030','Wednesday','9:00am - 9:30am'),('axc157030','Wednesday','9:30am - 10:00am'),('sxa173731','Thursday','10:00am - 10:30am'),('sxa173731','Thursday','10:30am - 11:00am'),('sxa173731','Thursday','11:00am - 11:30am'),('sxa173731','Thursday','11:30am - 12:00pm'),('sxa173731','Thursday','12:30pm - 1:00pm'),('sxa173731','Thursday','2:30pm - 3:00pm'),('sxa173731','Thursday','3:00pm - 3:30pm'),('sxa173731','Thursday','3:30pm - 4:00pm'),('sxa173731','Thursday','5:30pm - 6:00pm'),('sxa173731','Thursday','6:00pm - 6:30pm'),('sxa173731','Thursday','6:30pm - 7:00pm'),('sxa173731','Tuesday','10:00am - 10:30am'),('sxa173731','Tuesday','10:30am - 11:00am'),('sxa173731','Tuesday','11:00am - 11:30am'),('sxa173731','Tuesday','11:30am - 12:00pm'),('sxa173731','Tuesday','12:30pm - 1:00pm'),('sxa173731','Tuesday','2:30pm - 3:00pm'),('sxa173731','Tuesday','3:00pm - 3:30pm'),('sxa173731','Tuesday','3:30pm - 4:00pm'),('sxa173731','Tuesday','5:30pm - 6:00pm'),('sxa173731','Tuesday','6:00pm - 6:30pm'),('sxa173731','Tuesday','6:30pm - 7:00pm');
/*!40000 ALTER TABLE `availability` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-26  9:55:20
